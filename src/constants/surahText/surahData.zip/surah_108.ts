const surah108 = [
  {
    id: '47_00',
    verseNumber: 0,
    ayah: 'بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ',
  },
  {
    id: '108_1',
    verseNumber: 1,
    ayah: 'إِنَّا أَعْطَيْنَاكَ الْكَوْثَرَ ﴿١﴾',
  },
  {
    id: '108_2',
    verseNumber: 2,
    ayah: 'فَصَلِّ لِرَبِّكَ وَانْحَرْ ﴿٢﴾',
  },
  {
    id: '108_3',
    verseNumber: 3,
    ayah: 'إِنَّ شَانِئَكَ هُوَ الْأَبْتَرُ ﴿٣﴾',
  },
];

export default surah108;
