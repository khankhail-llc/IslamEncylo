const surah112 = [
  {
    id: '47_00',
    verseNumber: 0,
    ayah: 'بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ',
  },
  {
    id: '112_1',
    verseNumber: 1,
    ayah: 'قُلْ هُوَ اللَّهُ أَحَدٌ ﴿١﴾',
  },
  {
    id: '112_2',
    verseNumber: 2,
    ayah: 'اللَّهُ الصَّمَدُ ﴿٢﴾',
  },
  {
    id: '112_3',
    verseNumber: 3,
    ayah: 'لَمْ يَلِدْ وَلَمْ يُولَدْ ﴿٣﴾',
  },
  {
    id: '112_4',
    verseNumber: 4,
    ayah: 'وَلَمْ يَكُنْ لَهُ كُفُوًا أَحَدٌ ﴿٤﴾',
  },
];

export default surah112;
